# Harness test payload.
# Goals:
#   * prove the update actually ran (drop a marker file)
#   * show a "Success" popup ON THE LOGGED-IN USER'S DESKTOP, even though the
#     harness runs as a LocalSystem service in session 0 (a normal MessageBox
#     would be invisible there -- we use WTSSendMessage to reach the user session)
#   * NEVER create a console/cmd window (harness runs us hidden; we spawn nothing)

$stamp  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$marker = Join-Path $env:ProgramData 'harness-test-success.txt'
try { Add-Content -LiteralPath $marker -Value "success $stamp" } catch { }

try {
    if (-not ('Win.WtsMsg' -as [type])) {
        Add-Type -Namespace Win -Name WtsMsg -MemberDefinition @'
[DllImport("kernel32.dll")]
public static extern uint WTSGetActiveConsoleSessionId();
[DllImport("wtsapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
public static extern bool WTSSendMessage(IntPtr hServer, uint SessionId,
    String pTitle,   uint TitleLength,
    String pMessage, uint MessageLength,
    uint Style, uint Timeout, out uint pResponse, bool bWait);
'@
    }
    $sid = [Win.WtsMsg]::WTSGetActiveConsoleSessionId()
    if ($sid -ne [uint32]::MaxValue) {          # 0xFFFFFFFF = nobody logged in at the console
        $title = 'Update Test'
        $body  = "Success`n`nThe harness ran this PowerShell payload.`n$stamp"
        $resp  = 0
        # Style 0x40 = MB_OK | MB_ICONINFORMATION ; Timeout 0 = stays until clicked ;
        # bWait $false = return immediately (don't block the harness on the click).
        [void][Win.WtsMsg]::WTSSendMessage([IntPtr]::Zero, $sid,
            $title, [uint32]($title.Length * 2),
            $body,  [uint32]($body.Length  * 2),
            0x40, 0, [ref]$resp, $false)
    }
} catch { }

exit 0
